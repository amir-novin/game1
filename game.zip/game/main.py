"""نقطه شروع بازی: داخل همین پوشه بزن  python main.py"""

import os
import sys
import time

import keyboard
from config import FPS
from dino_game import Game


def main():
    os.system("")  # فعال کردن کد‌های ANSI در cmd ویندوز
    keyboard.setup()
    sys.stdout.write("\x1b[2J\x1b[?25l")  # پاک کردن صفحه + مخفی کردن مکان‌نما

    game = Game()
    try:
        while True:
            start = time.time()
            key = keyboard.get_key()

            if key == "quit":
                break
            if key == "restart":
                game = Game(game.high_score)
                key = None
            if key == "up":
                game.jump()

            game.update()

            frame = "\n".join(line + "\x1b[K" for line in game.render())
            sys.stdout.write("\x1b[H" + frame + "\x1b[J")
            sys.stdout.flush()

            delay = 1 / FPS - (time.time() - start)
            if delay > 0:
                time.sleep(delay)
    except KeyboardInterrupt:
        pass
    finally:
        keyboard.restore()
        sys.stdout.write("\x1b[?25h\nBye!\n")  # برگردوندن مکان‌نما
        sys.stdout.flush()


if __name__ == "__main__":
    main()

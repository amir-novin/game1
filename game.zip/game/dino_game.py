"""منطق و نمایش بازی دایناسور."""

import random

from config import (
    WIDTH, HEIGHT, GROUND, DINO_X,
    GRAVITY, JUMP_SPEED,
    MAX_SPEED, SPEED_UP_EVERY, MIN_GAP, MAX_GAP,
)

LEGS = ["d", "b"]  # دو حالت پا برای انیمیشن دویدن


class Game:
    def __init__(self, high_score=0):
        self.dino_y = float(GROUND)
        self.vel = 0.0
        self.obstacles = []      # هر مانع: [ستون x, ارتفاع]
        self.score = 0
        self.high_score = high_score
        self.speed = 1
        self.frame = 0
        self.next_spawn = 25
        self.alive = True

    @property
    def on_ground(self):
        return self.dino_y >= GROUND

    def jump(self):
        if self.on_ground and self.alive:
            self.vel = JUMP_SPEED

    def update(self):
        if not self.alive:
            return
        self.frame += 1

        # فیزیک پرش
        self.vel += GRAVITY
        self.dino_y += self.vel
        if self.dino_y >= GROUND:
            self.dino_y = float(GROUND)
            self.vel = 0.0

        # حرکت کاکتوس‌ها
        for ob in self.obstacles:
            ob[0] -= self.speed
        self.obstacles = [ob for ob in self.obstacles if ob[0] > -3]

        # ساخت کاکتوس جدید
        self.next_spawn -= self.speed
        if self.next_spawn <= 0:
            self.obstacles.append([WIDTH - 1, random.choice([1, 1, 2])])
            self.next_spawn = random.randint(MIN_GAP, MAX_GAP)

        # برخورد
        dy = int(round(self.dino_y))
        for ox, oh in self.obstacles:
            overlap = ox <= DINO_X + 1 and ox + 1 >= DINO_X
            if overlap and dy > GROUND - oh:
                self.alive = False

        # امتیاز و سرعت
        self.score += 1
        self.speed = min(MAX_SPEED, 1 + self.score // SPEED_UP_EVERY)
        self.high_score = max(self.high_score, self.score)

    def render(self):
        grid = [[" "] * WIDTH for _ in range(HEIGHT)]

        # زمین
        for x in range(WIDTH):
            grid[GROUND + 1][x] = "_" if (x + self.frame) % 7 else "."

        # کاکتوس‌ها
        for ox, oh in self.obstacles:
            for h in range(oh):
                y = GROUND - h
                if 0 <= ox < WIDTH:
                    grid[y][ox] = "#"
                if 0 <= ox + 1 < WIDTH and h == 0:
                    grid[y][ox + 1] = "#"

        # دایناسور
        dy = int(round(self.dino_y))
        if not self.alive:
            leg = "x"
        elif self.on_ground:
            leg = LEGS[(self.frame // 2) % 2]
        else:
            leg = "d"
        grid[dy][DINO_X - 1] = leg
        grid[dy][DINO_X] = "O"
        grid[dy][DINO_X + 1] = ">"
        if dy - 1 >= 0:
            grid[dy - 1][DINO_X] = "O"
            grid[dy - 1][DINO_X + 1] = "@"

        lines = ["".join(row) for row in grid]
        header = f" DINO  |  Score: {self.score:05d}  |  High: {self.high_score:05d}"
        footer = " [Space / Up] Jump    [R] Restart    [Q] Quit"
        out = [header, "=" * WIDTH] + lines + ["=" * WIDTH, footer]
        if not self.alive:
            out += ["", "   GAME OVER!  Press R to restart or Q to quit."]
        else:
            out += ["", ""]
        return out

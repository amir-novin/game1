"""خوندن کلید‌های کیبورد بدون نیاز به Enter (ویندوز / لینوکس / مک)."""

import os
import sys

if os.name == "nt":
    import msvcrt

    def setup():
        pass

    def restore():
        pass

    def get_key():
        key = None
        while msvcrt.kbhit():
            ch = msvcrt.getwch()
            if ch in ("\x00", "\xe0"):      # کلید‌های ویژه مثل فلش‌ها
                ch2 = msvcrt.getwch()
                if ch2 == "H":              # فلش بالا
                    key = "up"
            elif ch == " ":
                key = "up"
            elif ch.lower() == "q":
                key = "quit"
            elif ch.lower() == "r":
                key = "restart"
        return key

else:
    import select
    import termios
    import tty

    _old = None

    def setup():
        global _old
        _old = termios.tcgetattr(sys.stdin)
        tty.setcbreak(sys.stdin.fileno())

    def restore():
        if _old:
            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, _old)

    def get_key():
        key = None
        while select.select([sys.stdin], [], [], 0)[0]:
            ch = sys.stdin.read(1)
            if ch == " ":
                key = "up"
            elif ch == "\x1b":
                seq = sys.stdin.read(2)
                if seq == "[A":
                    key = "up"
            elif ch.lower() == "q":
                key = "quit"
            elif ch.lower() == "r":
                key = "restart"
        return key

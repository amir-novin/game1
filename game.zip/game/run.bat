@echo off
title Dino Game
python main.py
if errorlevel 1 py main.py
pause
